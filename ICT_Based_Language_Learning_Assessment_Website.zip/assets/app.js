const modules = Array.isArray(window.MODULES) ? window.MODULES : [];
const grid = document.getElementById('module-grid');
const search = document.getElementById('search');
const category = document.getElementById('category');
const empty = document.getElementById('empty-state');
document.getElementById('year').textContent = new Date().getFullYear();
document.getElementById('total-modules').textContent = modules.length;
const categories = [...new Set(modules.map(m => m.category).filter(Boolean))].sort();
document.getElementById('total-categories').textContent = categories.length;
categories.forEach(c => { const o=document.createElement('option'); o.value=c; o.textContent=c; category.appendChild(o); });
function render(){
 const q=search.value.trim().toLowerCase(), c=category.value;
 const filtered=modules.filter(m => [m.title,m.course,m.category,m.description].join(' ').toLowerCase().includes(q) && (!c || m.category===c));
 grid.innerHTML='';
 filtered.forEach(m=>{
  const card=document.createElement('article'); card.className='module-card';
  const top=document.createElement('div'); top.className='module-top';
  const ico=document.createElement('span'); ico.className='file-icon'; ico.textContent=m.type==='PDF'?'PDF':'▤';
  const tag=document.createElement('span'); tag.className='tag'; tag.textContent=m.category||'Materi';
  top.append(ico,tag);
  const h=document.createElement('h3'); h.textContent=m.title||'Tanpa judul';
  const p=document.createElement('p'); p.textContent=(m.course?m.course+' • ':'')+(m.description||'');
  const meta=document.createElement('div'); meta.className='module-meta';
  const date=document.createElement('small'); date.textContent=m.updated||'';
  const a=document.createElement('a'); a.className='open-link'; a.href=m.file||'#'; a.target='_blank'; a.rel='noopener'; a.textContent=m.type==='PDF'?'Buka / Unduh →':'Buka Modul →';
  meta.append(date,a); card.append(top,h,p,meta); grid.append(card);
 });
 empty.hidden=filtered.length!==0;
}
search.addEventListener('input',render); category.addEventListener('change',render); render();
