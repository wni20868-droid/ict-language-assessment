// DAFTAR MODUL: tambahkan objek baru di dalam tanda kurung siku [ ... ].
// Simpan file HTML/PDF di folder modules/, lalu tuliskan alamat filenya pada field "file".
window.MODULES = [
  {
    title: "Contoh Modul ICT-Based Language Learning Assessment",
    course: "MPBI — Universitas Islam Malang",
    category: "Language Learning Assessment",
    description: "Contoh entri katalog. Ganti dengan judul dan deskripsi materi perkuliahan.",
    file: "modules/contoh-modul.html",
    type: "HTML",
    updated: "13 November 2026"
  }
];
