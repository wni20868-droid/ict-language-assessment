# ICT-Based Language Learning Assessment — Panduan Pengelola

Website ini adalah website statis yang dapat di-host gratis melalui GitHub Pages. Mahasiswa dapat mengakses alamat website tanpa akun (jika repositori dibuat Public).

## Cara menambahkan modul baru
1. Siapkan file modul berformat HTML. Untuk PDF, simpan PDF di folder `modules/` juga.
2. Unggah file ke folder `modules/` melalui GitHub.
3. Buka file `modules.js` dan tambahkan satu objek baru di dalam array `window.MODULES`, misalnya:

```js
{
  title: "Konsep Dasar Pendidikan",
  course: "Pengantar Pendidikan",
  category: "Materi Kuliah",
  description: "Bahan belajar pertemuan 1–2.",
  file: "modules/konsep-dasar.html",
  type: "HTML",
  updated: "20 November 2026"
}
```
4. Simpan perubahan (Commit changes). Website akan diperbarui otomatis setelah GitHub Pages selesai membangun situs.

Untuk PDF, ubah `file` menjadi misalnya `modules/modul-pertemuan-1.pdf` dan `type` menjadi `PDF`.

## Cara menerbitkan website gratis
1. Buat akun di https://github.com jika belum punya.
2. Buat repository baru, misalnya `modul-digital`, dan pilih **Public**.
3. Unggah seluruh isi folder paket ini ke repository (file `index.html` harus berada di root repository).
4. Buka **Settings → Pages**.
5. Pada bagian Build and deployment, pilih **Deploy from a branch**.
6. Pilih branch `main`, folder `/(root)`, lalu klik **Save**.
7. Tunggu proses publikasi. Alamat website biasanya berbentuk `https://USERNAME.github.io/modul-digital/`.

## Catatan penting
- Hosting GitHub Pages gratis untuk repository publik dan cocok untuk materi yang memang boleh diakses umum.
- Website ini belum memiliki login, panel admin, atau database. Penambahan modul dilakukan melalui GitHub, bukan melalui formulir unggah di halaman mahasiswa.
- Jangan unggah data pribadi mahasiswa, materi berlisensi yang tidak boleh dibagikan, atau dokumen rahasia.
- File HTML sebaiknya mandiri atau menggunakan aset dengan path relatif. Periksa tautan gambar, CSS, dan JavaScript setelah diunggah.
